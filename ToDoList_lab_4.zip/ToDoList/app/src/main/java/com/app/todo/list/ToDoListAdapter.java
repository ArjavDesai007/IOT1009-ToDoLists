package com.app.todo.list;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ToDoListAdapter extends BaseAdapter {


    private final ArrayList<ModelList> todoList;
    LayoutInflater inflater;  //for inflate layout items

    public ToDoListAdapter(Context context, ArrayList<ModelList> todoList)
    {
        // constructor for initialize list
        this.todoList = todoList;
        inflater=(LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        // return total count of list
        return todoList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        // set item view
        view = inflater.inflate(R.layout.item_list,viewGroup,false);

        // casting view
        TextView title = view.findViewById(R.id.title);
        TextView description = view.findViewById(R.id.description);
        ImageView remove = view.findViewById(R.id.removeNote);

        // on click remove current note
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // remove item and refresh list
                if (!todoList.isEmpty()){
                    todoList.remove(position);
                    notifyDataSetChanged();
                }
            }
        });

        // set current item from list and show
        title.setText(todoList.get(position).title);
        description.setText(todoList.get(position).description);

        return view;
    }
}
