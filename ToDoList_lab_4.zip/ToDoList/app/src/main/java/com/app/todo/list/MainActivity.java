package com.app.todo.list;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // listview
    ListView customList;

    //model class array for list
    ArrayList<ModelList> todoList = new ArrayList<>();

    //list adapter
    private ToDoListAdapter todoListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customList = findViewById(R.id.listview);

        //set adapetr with blank list
        todoListAdapter = new ToDoListAdapter(this, todoList);
        customList.setAdapter(todoListAdapter);

        // list item click and print title
        customList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Toast.makeText(MainActivity.this, todoList.get(position).title, Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void addNewItem(View view) {

        ModelList modelList = new ModelList();

        // open dialog for add new note
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_item);

        // set layout_width for dialog view
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        // edittext and button casting
        EditText title = (EditText) dialog.findViewById(R.id.edtTitle);
        EditText description = (EditText) dialog.findViewById(R.id.edtDescription);
        ImageView cancelDialog = (ImageView) dialog.findViewById(R.id.cancelDialog);
        Button btnSave = (Button) dialog.findViewById(R.id.btnSave);

        //save  button on click
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // check is black value
                if (TextUtils.isEmpty(title.getText().toString())
                        || TextUtils.isEmpty(description.getText().toString())) {
                    Toast.makeText(MainActivity.this, "Please enter the above empty field", Toast.LENGTH_SHORT).show();
                } else {
                    // add entered value in model class
                    modelList.setTitle(title.getText().toString().trim());
                    modelList.setDescription(description.getText().toString().trim());

                    // add model class object in list
                    todoList.add(modelList);

                    // refresh list
                    todoListAdapter.notifyDataSetChanged();

                    // close dialog
                    dialog.dismiss();
                }
            }
        });

        cancelDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // close dialog
                dialog.dismiss();
            }
        });

        // show dialog
        dialog.show();

    }
}